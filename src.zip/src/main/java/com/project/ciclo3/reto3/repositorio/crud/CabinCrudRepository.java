package com.project.ciclo3.reto3.repositorio.crud;

import com.project.ciclo3.reto3.modelo.Cabin;
import org.springframework.data.repository.CrudRepository;

public interface CabinCrudRepository extends CrudRepository<Cabin,Integer> {

}
