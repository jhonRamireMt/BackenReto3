package com.project.ciclo3.reto3.repositorio.crud;

import com.project.ciclo3.reto3.modelo.Category;
import org.springframework.data.repository.CrudRepository;

public interface CategoryCrudRepository extends CrudRepository<Category,Integer> {
}
